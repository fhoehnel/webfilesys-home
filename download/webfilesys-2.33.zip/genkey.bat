rem the Java SSL libraries must be available in the lib/ext subdirectory of the JRE
rem sample script to create a self-signed certificate for SSL
keytool -genkey -dname "cn=Frank Hoehnel, ou=fmweb author, o=fmweb development, c=DE" -alias fmweb -keypass fmweb1998 -keystore fmweb.keystore -storepass fmweb1998 -validity 3650 -keyalg RSA
